// src/lib/whatsappShare.ts

import { Alert, Linking, Platform, ToastAndroid } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import * as Print from 'expo-print';
import * as FileSystem from 'expo-file-system/legacy';
import type { CustomerOrder } from './api/customerOrders';
import type { InvoiceDetail } from '../types/invoices';
import { getCompanySettings } from './api/settings';
import { formatDisplayDate } from './dateUtils';
// import type { ShareableProduct } from '...'; // <- keep your existing import for ShareableProduct

// react-native-share is a native module: it does not exist in Expo Go.
// Load it lazily so the app still starts there and falls back gracefully.
let RNShare: any = null;
let RNSocial: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const mod = require('react-native-share');
  RNShare = mod?.default ?? mod;
  RNSocial = mod?.Social ?? RNShare?.Social ?? null;
} catch {
  RNShare = null;
  RNSocial = null;
}

export interface ShopShareInfo {
  name: string;
  address: string | null;
  mapsUrl: string | null;
  website?: string | null;
}

// ---------------------------------------------------------
// Shop info from the company settings row.
//
// Field names are read defensively because I haven't seen your
// company_settings columns. If your table uses different names,
// add them to the fallback chains below.
// ---------------------------------------------------------
export function shopInfoFromCompany(company: any): ShopShareInfo {
  const name =
    company?.company_name ?? company?.shop_name ?? company?.business_name ?? company?.name ?? 'Our Shop';

  const addressParts = [
    company?.address ?? company?.address_line1,
    company?.address_line2,
    company?.city,
    company?.state,
    company?.pincode ?? company?.postal_code,
  ]
    .map((p) => (p == null ? '' : String(p).trim()))
    .filter(Boolean);

  const address = addressParts.length ? addressParts.join(', ') : null;

  // Prefer an explicit Google Maps link if the settings have one;
  // otherwise build a search link from the address text.
  const explicitMaps =
    company?.google_maps_url ?? company?.maps_url ?? company?.map_link ?? company?.location_url ?? null;

  const mapsUrl = explicitMaps
    ? String(explicitMaps)
    : address
      ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name}, ${address}`)}`
      : null;

  // Website: add https:// if the DB value has no scheme so WhatsApp makes it tappable.
  const rawWebsite =
    company?.website ?? company?.website_url ?? company?.shop_website ?? company?.web_url ?? null;
  let website = rawWebsite ? String(rawWebsite).trim() : '';
  if (website && !/^https?:\/\//i.test(website)) website = `https://${website}`;

  return { name: String(name), address, mapsUrl, website: website || null };
}

// ---------------------------------------------------------
// Phone → WhatsApp format (digits only, country code included).
// 10-digit Indian numbers get 91 prepended.
// ---------------------------------------------------------
export function normalizeWhatsAppPhone(raw?: string | null, defaultCountryCode = '91'): string | null {
  if (!raw) return null;
  let digits = raw.replace(/\D/g, '').replace(/^0+/, '');
  if (!digits) return null;
  if (digits.length === 10) digits = defaultCountryCode + digits;
  return digits.length >= 11 ? digits : null;
}

// ---------------------------------------------------------
// Shared: open WhatsApp with a text message (directly to a number
// when we have one, otherwise the contact picker).
// ---------------------------------------------------------
async function openWhatsApp(message: string, phone?: string | null): Promise<void> {
  const encoded = encodeURIComponent(message);

  const appUrl = phone ? `whatsapp://send?phone=${phone}&text=${encoded}` : `whatsapp://send?text=${encoded}`;
  const webUrl = phone ? `https://wa.me/${phone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;

  if (Platform.OS === 'web') {
    await Linking.openURL(webUrl);
    return;
  }

  try {
    const supported = await Linking.canOpenURL(appUrl);
    await Linking.openURL(supported ? appUrl : webUrl);
  } catch {
    await Linking.openURL(webUrl);
  }
}

// =========================================================
// Products: single + multiple product share
// =========================================================

export interface ShareableProductWithImage extends ShareableProduct {
  imageUrl?: string | null;
}

function buildProductLines(p: ShareableProduct, imageUrl?: string | null, indent = ''): string[] {
  const lines: string[] = [];
  if (p.metals?.name) lines.push(`${indent}Metal: ${p.metals.name}`);
  if (p.purities?.name) lines.push(`${indent}Purity: ${p.purities.name}`);
  if (p.net_weight != null) lines.push(`${indent}Weight: ${Number(p.net_weight).toFixed(3)} g`);
  if (imageUrl) lines.push(`${indent}${imageUrl}`);
  return lines;
}

// Shop name on top, website at the bottom. The website is last so the
// product image stays the first URL (WhatsApp previews only the first URL).
function wrapWithShopInfo(body: string, shop?: ShopShareInfo | null): string {
  const header = shop?.name ? `*${shop.name}*\n\n` : '';
  const footer = shop?.website ? `\n\n${shop.website}` : '';
  return `${header}${body}${footer}`;
}

/**
 * Builds one WhatsApp message covering multiple products. Note: WhatsApp
 * only renders a link-preview thumbnail for the FIRST url it finds in a
 * message, so only the first product's image will show as a preview — the
 * rest are still included as plain tappable links.
 */
export function buildMultiProductShareMessage(
  products: ShareableProductWithImage[],
  shop?: ShopShareInfo | null
): string {
  const blocks = products.map((p, i) => {
    const lines = [`${i + 1}. *${p.product_name}*`, ...buildProductLines(p, p.imageUrl, '   ')];
    return lines.join('\n');
  });
  return wrapWithShopInfo(blocks.join('\n\n'), shop);
}

export function buildSingleProductShareMessage(
  product: ShareableProduct,
  imageUrl?: string | null,
  shop?: ShopShareInfo | null
): string {
  const lines = [`*${product.product_name}*`, ...buildProductLines(product, imageUrl)];
  return wrapWithShopInfo(lines.join('\n'), shop);
}

export async function getShopShareInfo(): Promise<ShopShareInfo> {
  const company = await getCompanySettings();
  return shopInfoFromCompany(company);
}

export async function shareProductsOnWhatsApp(
  products: ShareableProductWithImage[],
  shop?: ShopShareInfo | null
): Promise<void> {
  if (!products.length) return;
  await openWhatsApp(buildMultiProductShareMessage(products, shop));
}

export async function shareProductOnWhatsApp(
  product: ShareableProduct,
  imageUrl?: string | null,
  shop?: ShopShareInfo | null
): Promise<void> {
  await openWhatsApp(buildSingleProductShareMessage(product, imageUrl, shop));
}

// =========================================================
// Order-ready message
// =========================================================
export function buildOrderReadyMessage(
  order: CustomerOrder,
  customerName: string | null,
  shop: ShopShareInfo
): string {
  const lines: string[] = [`*${shop.name}*`, ''];

  lines.push(customerName ? `Hello ${customerName},` : 'Hello,');
  lines.push('Your jewel order is ready! 🎉', '');

  lines.push('*Order Details*');
  lines.push(`Order No: ${order.order_number}`);
  lines.push(`Item: ${order.category}`);
  lines.push(`Metal: ${order.metal} (${order.purity})`);
  lines.push(`Weight: ${order.weight_min}g – ${order.weight_max}g`);
  if (order.stone_name) {
    lines.push(`Stone: ${order.stone_name}${order.stone_weight != null ? ` (${order.stone_weight} ct)` : ''}`);
  }
  if (order.due_date) {
    lines.push(`Due Date: ${formatDisplayDate(order.due_date)}`);
  }

  if (shop.address || shop.mapsUrl) {
    lines.push('', '📍 *Visit us*');
    if (shop.address) lines.push(shop.address);
    if (shop.mapsUrl) lines.push(shop.mapsUrl);
  }

  lines.push('', 'Thank you for choosing us!');
  return lines.join('\n');
}

export async function shareOrderReadyOnWhatsApp(params: {
  order: CustomerOrder;
  customerName: string | null;
  customerPhone: string | null;
  shop: ShopShareInfo;
}): Promise<void> {
  const { order, customerName, customerPhone, shop } = params;

  const message = buildOrderReadyMessage(order, customerName, shop);
  const phone = normalizeWhatsAppPhone(customerPhone);

  await openWhatsApp(message, phone);
}

// =========================================================
// Invoice: PDF + thank-you note + Google review link
// in ONE WhatsApp message
// =========================================================

// Fallback if your company settings don't have a review link column.
// Paste your Google review link here (Google Business Profile →
// "Ask for reviews" → copy link, e.g. https://g.page/r/XXXX/review).
export const DEFAULT_GOOGLE_REVIEW_URL = 'https://g.page/r/CStZEpxYDNSqECE/review';

export function reviewUrlFromCompany(company: any): string | null {
  const raw =
    company?.google_review_url ??
    company?.google_review_link ??
    company?.review_url ??
    company?.review_link ??
    null;
  const trimmed = raw ? String(raw).trim() : '';
  return trimmed || DEFAULT_GOOGLE_REVIEW_URL || null;
}

export function buildInvoiceThanksMessage(
  invoice: InvoiceDetail,
  shopName: string | null,
  reviewUrl: string | null
): string {
  const lines: string[] = [];
  const name =
    invoice.customer_name && invoice.customer_name !== 'Walk-in Customer' ? invoice.customer_name : 'there';
  lines.push(`Hi ${name},`);
  lines.push(`Thank you for shopping with *${shopName ?? 'us'}*! 🙏`, '');
  lines.push(`Invoice: ${invoice.invoice_number}`);
  lines.push(`Amount: ₹${Number(invoice.grand_total || 0).toLocaleString('en-IN')}`);
  lines.push('', 'Your invoice is attached.');

  if (reviewUrl) {
    lines.push('', 'We would love to hear your feedback — please rate us on Google:', `⭐ ${reviewUrl}`);
  }
  return lines.join('\n');
}

const escapeHtml = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Thank-you + Google review block that gets printed at the end of the invoice PDF. */
export function buildThankYouHtmlBlock(shopName: string | null, reviewUrl: string | null): string {
  const name = escapeHtml(shopName ?? 'us');
  const url = reviewUrl ? escapeHtml(reviewUrl) : '';
  return `
  <div style="margin-top:24px;padding:14px 16px;border:1px solid #ddd;border-radius:8px;text-align:center;font-family:Arial,sans-serif;font-size:13px;color:#333;page-break-inside:avoid;">
    <div style="font-size:15px;font-weight:bold;margin-bottom:6px;">Thank you for shopping with ${name}! 🙏</div>
    ${
      url
        ? `<div>We would love to hear your feedback. Please rate us on Google:</div>
           <div style="margin-top:4px;"><a href="${url}" style="color:#0B3D91;word-break:break-all;">${url}</a></div>`
        : ''
    }
  </div>`;
}

/** Inserts a block just before </body> (or appends it if there is no body tag). */
export function appendToHtml(html: string, block: string): string {
  const i = html.lastIndexOf('</body>');
  return i === -1 ? html + block : html.slice(0, i) + block + html.slice(i);
}

/**
 * Renders the invoice HTML to a PDF and returns a local file:// URI
 * named after the invoice number (e.g. INV-202609-00024.pdf).
 */
export async function createInvoicePdfFile(html: string, invoiceNumber: string): Promise<string> {
  const { uri } = await Print.printToFileAsync({ html, width: 595, height: 842 });
  const safeName = invoiceNumber.replace(/[^a-zA-Z0-9_-]/g, '_');
  const dest = `${FileSystem.cacheDirectory}${safeName}.pdf`;
  await FileSystem.deleteAsync(dest, { idempotent: true });
  await FileSystem.moveAsync({ from: uri, to: dest });
  return dest;
}

/**
 * One tap: PDF + thank-you note + review link in a single WhatsApp message.
 *
 * - Dev build / production build: uses react-native-share to open the
 *   customer's WhatsApp chat with the PDF attached and the note as caption.
 * - Expo Go / WhatsApp missing: copies the note to the clipboard and opens the
 *   normal share sheet with the PDF; the user pastes the note as the caption.
 */
export async function shareInvoiceOnWhatsApp(params: {
  invoice: InvoiceDetail;
  shopName: string | null;
  reviewUrl: string | null;
  /** Returns a local file:// URI of the generated PDF. */
  getPdfUri: () => Promise<string>;
  /** Plain share sheet / print dialog, used on web and as fallback. */
  sharePdfFallback: () => Promise<void>;
}): Promise<void> {
  const { invoice, shopName, reviewUrl, getPdfUri, sharePdfFallback } = params;

  const message = buildInvoiceThanksMessage(invoice, shopName, reviewUrl);
  const phone = normalizeWhatsAppPhone(invoice.customer_mobile);

  if (Platform.OS === 'web') {
    await sharePdfFallback();
    return;
  }

  const pdfUri = await getPdfUri();

  // WhatsApp often ignores the text when a PDF is attached, so the note is
  // always on the clipboard as a safety net. Paste it into the caption box
  // if it doesn't appear on its own.
  await Clipboard.setStringAsync(message);
  if (Platform.OS === 'android') {
    ToastAndroid.show('Note copied. If the caption is empty, long-press and paste.', ToastAndroid.LONG);
  }

  // Native module missing (Expo Go)
  if (!RNShare?.shareSingle || !RNSocial?.Whatsapp) {
    Alert.alert('Message copied', 'Pick WhatsApp, then paste the message as the caption.', [
      { text: 'OK', onPress: () => void sharePdfFallback() },
    ]);
    return;
  }

  try {
    await RNShare.shareSingle({
      social: RNSocial.Whatsapp,
      url: pdfUri,
      type: 'application/pdf',
      filename: invoice.invoice_number,
      message,
      whatsAppNumber: phone ?? undefined, // opens the customer's chat directly
    });
  } catch (e: any) {
    const msg = String(e?.message ?? '').toLowerCase();

    // User closed WhatsApp / cancelled -> do nothing
    if (msg.includes('cancel') || msg.includes('did not share')) return;

    // WhatsApp not installed or intent failed -> normal share sheet
    await sharePdfFallback();
  }
}