// app/(tabs)/products/add.tsx
import { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, Modal } from 'react-native';
import { useRouter } from 'expo-router';
import { CheckCircle2 } from 'lucide-react-native';
import { colors, spacing } from '../../../src/theme';
import { SelectField, SelectOption } from '../../../src/components/ui/SelectField';
import { MultiSelectField } from '../../../src/components/ui/MultiSelectField';
import { ImagePickerGrid, PickedImage } from '../../../src/components/product/ImagePickerGrid';
import {
  getMetals, getPurities, getCategories, getSubcategories, getStoneNames,
  createProduct, insertProductImages, saveProductCharges,
} from '../../../src/lib/products';
import {
  listTaxSettings,
  createCategory,
  createSubcategory,
  createPurity,
  createStoneName,
} from '../../../src/lib/api/settings';
import type { TaxSetting } from '../../../src/types/settings';
import { uploadProductImageBase64 } from '../../../src/lib/storage';
import { useStaff } from '../../../src/context/StaffContext';
import { useNotifications } from '../../../src/context/NotificationContext';

// How long the "Product Saved" popup stays up before auto-navigating to the
// product list. A tap on "View Now" inside the popup skips the wait.
const SAVED_POPUP_AUTO_NAV_MS = 1500;

// Route to the product list screen. Update this if your list screen lives
// somewhere else (e.g. a different segment name under (tabs)/products).
const PRODUCT_LIST_ROUTE = '/products';

export default function AddProductScreen() {
  const router = useRouter();
  const { currentStaff } = useStaff();
  const { notify } = useNotifications();
  const [loadingMeta, setLoadingMeta] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedProduct, setSavedProduct] = useState<any>(null);
  const autoNavTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [metals, setMetals] = useState<SelectOption[]>([]);
  const [purities, setPurities] = useState<SelectOption[]>([]);
  const [categories, setCategories] = useState<SelectOption[]>([]);
  const [subcategories, setSubcategories] = useState<SelectOption[]>([]);

  const [productName, setProductName] = useState('');
  const [metalId, setMetalId] = useState<string | null>(null);
  const [purityId, setPurityId] = useState<string | null>(null);
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [subcategoryId, setSubcategoryId] = useState<string | null>(null);
  const [brand, setBrand] = useState('');
  const [huid, setHuid] = useState('');
  const [designNumber, setDesignNumber] = useState('');
  const [hsnCode, setHsnCode] = useState('7113');

  const [grossWeight, setGrossWeight] = useState('');
  const [stoneWeight, setStoneWeight] = useState('');
  const [otherWeight, setOtherWeight] = useState('');

  // Size (e.g. ring size, bangle size) — free text, stored directly on the product.
  const [size, setSize] = useState('');

  // Stone names on this product — a product can carry more than one stone
  // (e.g. a ruby AND a diamond on the same piece), so this is a dropdown
  // multi-select (checkboxes + OK/Cancel) backed by the stones master
  // table + product_stones join.
  const [stoneOptions, setStoneOptions] = useState<SelectOption[]>([]);
  const [stoneIds, setStoneIds] = useState<string[]>([]);

  // Per-product charges. These are NOT frozen money amounts — they're the
  // rule (percentage / fixed value) that gets applied against that day's
  // metal rate at invoice time, same philosophy as making_charge_rules.
  const [vacPercent, setVacPercent] = useState('');
  const [stoneChargeFixed, setStoneChargeFixed] = useState('');
  const [makingChargeFixed, setMakingChargeFixed] = useState('');

  // GST: a dropdown of active tax_settings rows. The chosen row's id is
  // stored on the product (tax_setting_id) so the invoice screen can apply
  // the exact rate this product was saved with, rather than always
  // guessing "the current default". taxSettings holds the raw rows so we
  // can look up the % for display; gstOptions is the SelectField-shaped list.
  const [taxSettings, setTaxSettings] = useState<TaxSetting[]>([]);
  const [gstOptions, setGstOptions] = useState<SelectOption[]>([]);
  const [gstSettingId, setGstSettingId] = useState<string | null>(null);

  const [images, setImages] = useState<PickedImage[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const [m, c, tax, stones] = await Promise.all([
          getMetals(),
          getCategories(),
          listTaxSettings(),
          getStoneNames(),
        ]);
        setMetals(m.map((x: any) => ({ id: x.id, label: x.name })));
        setCategories(c.map((x: any) => ({ id: x.id, label: x.name })));
        setStoneOptions((stones ?? []).map((x: any) => ({ id: x.id, label: x.name })));

        const activeTax = (tax ?? []).filter((t) => t.is_active);
        setTaxSettings(activeTax);
        setGstOptions(activeTax.map((t) => ({ id: t.id, label: `${t.tax_name} — ${t.tax_percentage}%` })));

        // Auto-pick a default: the most recently added active slab if the
        // rows come back newest-first, otherwise fall back to the highest
        // percentage. Either way the user can still change it.
        if (activeTax.length) {
          const byHighest = [...activeTax].sort((a, b) => b.tax_percentage - a.tax_percentage)[0];
          setGstSettingId(activeTax[0]?.id ?? byHighest.id);
        }
      } catch (e: any) {
        Alert.alert('Error', e.message ?? 'Failed to load master data');
      } finally {
        setLoadingMeta(false);
      }
    })();
  }, []);

  useEffect(() => {
    setPurityId(null); setPurities([]);
    if (!metalId) return;
    getPurities(metalId).then((p) => setPurities(p.map((x: any) => ({ id: x.id, label: x.name })))).catch((e) => Alert.alert('Error', e.message));
  }, [metalId]);

  useEffect(() => {
    setSubcategoryId(null); setSubcategories([]);
    if (!categoryId) return;
    getSubcategories(categoryId).then((s) => setSubcategories(s.map((x: any) => ({ id: x.id, label: x.name })))).catch((e) => Alert.alert('Error', e.message));
  }, [categoryId]);

  // Clear any pending auto-navigate timer if the screen unmounts early
  // (e.g. user backs out manually before the popup finishes its countdown).
  useEffect(() => {
    return () => {
      if (autoNavTimer.current) clearTimeout(autoNavTimer.current);
    };
  }, []);

  const grossNum = parseFloat(grossWeight) || 0;
  const stoneNum = parseFloat(stoneWeight) || 0;
  const otherNum = parseFloat(otherWeight) || 0;
  const netWeight = Math.max(grossNum - stoneNum - otherNum, 0);

  function validate(): string | null {
    if (!productName.trim()) return 'Product name is required';
    if (!metalId) return 'Select a metal';
    if (!purityId) return 'Select a purity';
    if (!grossWeight || grossNum <= 0) return 'Enter gross weight';
    return null;
  }

  function goToProductList() {
    if (autoNavTimer.current) clearTimeout(autoNavTimer.current);
    router.replace(PRODUCT_LIST_ROUTE as never);
  }

  // ---------- Inline "Add New" handlers for the master-data dropdowns ----------
  // Each of these creates the record in Supabase via the shared settings API,
  // appends it to the relevant local options list (so it's selectable for
  // the rest of this session without a refetch), and returns the new
  // { id, label } option so the dropdown can auto-select it immediately.

  async function handleAddCategory(name: string): Promise<SelectOption> {
    const created = await createCategory({ name });
    const opt: SelectOption = { id: created.id, label: created.name };
    setCategories((prev) => [...prev, opt].sort((a, b) => a.label.localeCompare(b.label)));
    return opt;
  }

  async function handleAddSubcategory(name: string): Promise<SelectOption> {
    if (!categoryId) throw new Error('Select a category first');
    const created = await createSubcategory({ category_id: categoryId, name });
    const opt: SelectOption = { id: created.id, label: created.name };
    setSubcategories((prev) => [...prev, opt].sort((a, b) => a.label.localeCompare(b.label)));
    return opt;
  }

  async function handleAddPurity(name: string): Promise<SelectOption> {
    if (!metalId) throw new Error('Select a metal first');
    const created = await createPurity({ metal_id: metalId, name, purity_percentage: null });
    const opt: SelectOption = { id: created.id, label: created.name };
    setPurities((prev) => [...prev, opt].sort((a, b) => a.label.localeCompare(b.label)));
    return opt;
  }

  async function handleAddStoneName(name: string): Promise<SelectOption> {
    const created = await createStoneName({ name });
    const opt: SelectOption = { id: created.id, label: created.name };
    setStoneOptions((prev) => [...prev, opt].sort((a, b) => a.label.localeCompare(b.label)));
    return opt;
  }

  async function handleSave() {
    const err = validate();
    if (err) { Alert.alert('Missing information', err); return; }
    if (!currentStaff) {
      Alert.alert('Session expired', 'Please log in again.');
      return;
    }
    setSaving(true);
    try {
      const product = await createProduct({
        product_name: productName.trim(),
        category_id: categoryId,
        subcategory_id: subcategoryId,
        brand: brand || undefined,
        metal_id: metalId!,
        purity_id: purityId!,
        gross_weight: grossNum,
        stone_weight: stoneNum,
        other_weight: otherNum,
        net_weight: netWeight,
        hsn_code: hsnCode || undefined,
        huid: huid || undefined,
        design_number: designNumber || undefined,
        size: size || undefined,
        stone_ids: stoneIds,
        tax_setting_id: gstSettingId || undefined,
      }, currentStaff.id);

      if (images.length) {
        const uploaded = await Promise.all(
          images.map((img, idx) => uploadProductImageBase64(product.id, img.base64!, idx))
        );
        await insertProductImages(uploaded.map((u, idx) => ({
          product_id: product.id, storage_path: u.storagePath, is_primary: images[idx].isPrimary, sort_order: idx,
        })), currentStaff.id);
      }

      // Save the per-product charges (VAC %, Stone Charge, Making Charge).
      // Zero-value charges are skipped inside saveProductCharges, so leaving
      // any of these at 0 simply means "no charge of this kind" rather than
      // writing a useless row.
      await saveProductCharges(
        product.id,
        [
          { charge_name: 'Value Added Charge', calculation_type: 'percentage', value: parseFloat(vacPercent) || 0 },
          { charge_name: 'Stone Charge', calculation_type: 'fixed', value: parseFloat(stoneChargeFixed) || 0 },
          { charge_name: 'Making Charge', calculation_type: 'fixed', value: parseFloat(makingChargeFixed) || 0 },
        ],
        currentStaff.id
      );

      // Fire a notification for other staff logins. Isolated in its own
      // try/catch so a notification failure never blocks the success popup
      // for a product that already saved correctly.
      try {
        await notify(
          'product',
          'New product added',
          `${product.product_name} (${product.product_code}) was added to inventory`
        );
      } catch (notifyError) {
        console.warn('Failed to send product notification', notifyError);
      }

      // Show the "Product Saved" popup, then automatically move on to the
      // product list — no more static full-screen success state that
      // required a manual tap to leave.
      setSavedProduct(product);
      autoNavTimer.current = setTimeout(() => {
        router.replace(PRODUCT_LIST_ROUTE as never);
      }, SAVED_POPUP_AUTO_NAV_MS);
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'Failed to save product');
    } finally {
      setSaving(false);
    }
  }

  if (loadingMeta) {
    return <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <>
      <ScrollView contentContainerStyle={styles.screen}>
        <ImagePickerGrid images={images} onChange={setImages} />

        <Text style={styles.sectionTitle}>Basic Details</Text>
        <TextInput style={styles.input} placeholder="Product name" placeholderTextColor={colors.textMuted} value={productName} onChangeText={setProductName} />
        <SelectField
          label="Category"
          value={categoryId}
          options={categories}
          onChange={setCategoryId}
          onAddNew={handleAddCategory}
        />
        <SelectField
          label="Subcategory"
          value={subcategoryId}
          options={subcategories}
          onChange={setSubcategoryId}
          disabled={!categoryId}
          onAddNew={handleAddSubcategory}
        />

        <Text style={styles.sectionTitle}>Metal & Purity</Text>
        <SelectField label="Metal" value={metalId} options={metals} onChange={setMetalId} />
        <SelectField
          label="Purity"
          value={purityId}
          options={purities}
          onChange={setPurityId}
          disabled={!metalId}
          onAddNew={handleAddPurity}
        />

        <Text style={styles.sectionTitle}>Weight (grams)</Text>
        <View style={styles.row}>
          <TextInput style={[styles.input, styles.rowInput]} placeholder="Gross" placeholderTextColor={colors.textMuted} keyboardType="decimal-pad" value={grossWeight} onChangeText={setGrossWeight} />
          <TextInput style={[styles.input, styles.rowInput]} placeholder="Stone" placeholderTextColor={colors.textMuted} keyboardType="decimal-pad" value={stoneWeight} onChangeText={setStoneWeight} />
          <TextInput style={[styles.input, styles.rowInput]} placeholder="Other" placeholderTextColor={colors.textMuted} keyboardType="decimal-pad" value={otherWeight} onChangeText={setOtherWeight} />
        </View>
        <Text style={styles.netWeightText}>Net weight: {netWeight.toFixed(3)} g</Text>

        <Text style={styles.sectionTitle}>Stones</Text>
        <MultiSelectField
          options={stoneOptions}
          values={stoneIds}
          onChange={setStoneIds}
          placeholder="Select stones"
          onAddNew={handleAddStoneName}
        />
        {stoneOptions.length === 0 && (
          <Text style={styles.helperText}>No stone names yet — tap the field and use "+ Add New" to create one.</Text>
        )}
        <Text style={styles.sectionTitle}>Size</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Ring size 16, Bangle 2.4"
          placeholderTextColor={colors.textMuted}
          value={size}
          onChangeText={setSize}
        />

        <Text style={styles.sectionTitle}>Charges</Text>
        <View style={styles.row}>
          <TextInput
            style={[styles.input, styles.rowInput]}
            placeholder="V A %"
            placeholderTextColor={colors.textMuted}
            keyboardType="decimal-pad"
            value={vacPercent}
            onChangeText={setVacPercent}
          />
          <TextInput
            style={[styles.input, styles.rowInput]}
            placeholder="S C ₹"
            placeholderTextColor={colors.textMuted}
            keyboardType="decimal-pad"
            value={stoneChargeFixed}
            onChangeText={setStoneChargeFixed}
          />
          <TextInput
            style={[styles.input, styles.rowInput]}
            placeholder="M C ₹"
            placeholderTextColor={colors.textMuted}
            keyboardType="decimal-pad"
            value={makingChargeFixed}
            onChangeText={setMakingChargeFixed}
          />
        </View>

        <Text style={styles.sectionTitle}>HSN Code</Text>
        <TextInput style={styles.input} placeholder="HSN code" placeholderTextColor={colors.textMuted} value={hsnCode} onChangeText={setHsnCode} />

        <Text style={styles.sectionTitle}>Identifiers (optional)</Text>
        <TextInput style={styles.input} placeholder="HUID" placeholderTextColor={colors.textMuted} value={huid} onChangeText={setHuid} />
        <TextInput style={styles.input} placeholder="Design number" placeholderTextColor={colors.textMuted} value={designNumber} onChangeText={setDesignNumber} />
        <TextInput style={styles.input} placeholder="Brand" placeholderTextColor={colors.textMuted} value={brand} onChangeText={setBrand} />

        {gstOptions.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>GST</Text>
            <SelectField label="GST rate" value={gstSettingId} options={gstOptions} onChange={setGstSettingId} />
            
          </>
        )}

        <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving}>
          {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>Save Product</Text>}
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={!!savedProduct} transparent animationType="fade" onRequestClose={goToProductList}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <CheckCircle2 size={48} color={colors.primary} style={{ marginBottom: spacing.sm }} />
            <Text style={styles.successTitle}>Product Saved</Text>
            <Text style={styles.successSub}>{savedProduct?.product_name}</Text>
            <Text style={styles.successCode}>Code: {savedProduct?.product_code}</Text>
            <Text style={styles.successNote}>
              Pricing for this item will be calculated automatically using the metal rate on the day it's invoiced.
            </Text>
            <TouchableOpacity style={styles.viewNowBtn} onPress={goToProductList}>
              <Text style={styles.viewNowBtnText}>View Now</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  screen: { padding: spacing.lg, paddingBottom: spacing.xl * 2, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: spacing.lg, marginBottom: spacing.sm },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingVertical: 12, paddingHorizontal: spacing.md, fontSize: 15, color: colors.text, backgroundColor: colors.surface, marginBottom: spacing.sm },
  row: { flexDirection: 'column', gap: spacing.sm },
  rowInput: { flex: 1 },
  netWeightText: { color: colors.textMuted, fontSize: 13, marginBottom: spacing.sm },
  helperText: { color: colors.textMuted, fontSize: 12, marginTop: 2, marginBottom: spacing.sm, fontStyle: 'italic' },
  helperNote: { color: colors.textMuted, fontSize: 12, marginTop: spacing.md, fontStyle: 'italic' },
  saveBtn: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: spacing.lg },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.45)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  modalCard: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingVertical: spacing.xl,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
  },
  successTitle: { fontSize: 20, fontWeight: '700', color: colors.text, textAlign: 'center' },
  successSub: { fontSize: 14, color: colors.textMuted, textAlign: 'center', marginTop: 4 },
  successCode: { fontSize: 13, color: colors.textMuted, textAlign: 'center', marginTop: 2 },
  successNote: { fontSize: 12, color: colors.textMuted, textAlign: 'center', marginTop: spacing.md, fontStyle: 'italic' },
  viewNowBtn: { marginTop: spacing.lg, paddingVertical: 10, paddingHorizontal: 20 },
  viewNowBtnText: { color: colors.primary, fontWeight: '700', fontSize: 14 },
});